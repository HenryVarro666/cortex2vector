package org.math.array.util;

/**
 * BSD License
 * 
 * @author Yann RICHET
 */
public interface IndexFunction {
    public double fi(int i);
}
